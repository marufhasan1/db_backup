<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<style type="text/css">
		a{
			padding: 10px 20px;
			display: inline-block;
			background: #d3d3d3;
			border: 0;
			color: #000;
			text-decoration: none;
		}
	</style>
</head>
	<body>
		<a href="save.php">Save</a>
		<a href="download.php">Download</a>
		<a href="import.php">Import</a>
		<a href="table.php">Show Tables</a>
	</body>
</html>